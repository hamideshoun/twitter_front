import React, { Component } from "react";
import { connect } from "react-redux";
import { handleInitialData } from "../actions/shared";
import SearchBar from "../components/SearchBar"
import Tweet from "./Tweet";

class Dashboard extends Component {
  componentDidMount(){
    this.props.dispatch(handleInitialData());

  }
  render() {
    console.log(this.props);
    return (
      <div className="dashboard">
        <h3 className="center">Your Timeline</h3>
        <SearchBar />
        <ul className="dashbord-list">
          {this.props.tweetsIds.map(id => (
            <li key={id}>
              {/* <div>TWEET ID: {id} </div> */}
              <Tweet id={id} />
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

//destructuring tweets from state
function mapStateToProps({ tweets }) {
  return {
    tweetsIds: Object.keys(tweets).sort(
      //sorting from the newest to the oldest tweet
      //If compareFunction(a, b) is greater than 0, sort b to an index lower than a, i.e. b comes first.
      (a, b) => tweets[b].id - tweets[a].id
    )
  };
}

export default connect(mapStateToProps)(Dashboard);
